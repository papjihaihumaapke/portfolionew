import * as THREE from "https://cdn.skypack.dev/three@0.129.0/build/three.module.js";
import { GLTFLoader } from "https://cdn.skypack.dev/three@0.129.0/examples/jsm/loaders/GLTFLoader.js";

class PhoneShowcase {
  constructor() {
    this.phone = null;
    this.current = { x: 0, y: 0 };
    this.target = { x: 0, y: 0 };
    this.sections = document.querySelectorAll(".stage");
    this.lastScrollY = 0;

    this.positions = [
      { x: 1.4, y: 0 },
      { x: -1.1, y: 0 },
      { x: 1.0, y: 0 },
      { x: -0.8, y: 0 },
      { x: 0.8, y: 0 },
      { x: -0.6, y: 0 },
      { x: 0, y: 0 }
    ];

    this.setup();
  }

  setup() {
    const container = document.getElementById("container3D");

    this.scene = new THREE.Scene();

    this.camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    this.camera.position.set(0, 0.3, 4.8);

    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    this.renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(this.renderer.domElement);
    this.resize();

  
    const lightFront = new THREE.PointLight(0xffffff, 1.8, 10);
    lightFront.position.set(0, 1, 4);

    const lightBack = new THREE.PointLight(0xffffff, 1.1, 20);
    lightBack.position.set(0, 0, -4);

    const lightSide = new THREE.PointLight(0xffffff, 1.2, 25);
    lightSide.position.set(3, 1, 1);

    const ambient = new THREE.AmbientLight(0xffffff, 0.7);

    this.scene.add(lightFront, lightBack, lightSide, ambient);

    new GLTFLoader().load(
      "iphone_12_pro.glb",
      (g) => {
        this.phone = g.scene;
        this.phone.scale.set(0.02, 0.02, 0.02);
        this.scene.add(this.phone);
      },
      undefined,
      (err) => console.error("Model Load Error:", err)
    );

    window.addEventListener("resize", () => this.resize());
    document
      .querySelector(".scroll-container")
      .addEventListener("scroll", () => this.update());

    this.animate();
  }

  update() {
    const scroller = document.querySelector(".scroll-container");
    const scrollY = scroller.scrollTop;
    const speed = Math.abs(scrollY - this.lastScrollY);
    this.lastScrollY = scrollY;

    if (this.phone) {
      this.phone.rotation.y += 0.01;
      this.phone.rotation.x = speed * -0.0003;
      this.phone.rotation.z = speed * 0.0002;
    }

    let closest = 0;
    let minDist = Infinity;
    this.sections.forEach((sec, i) => {
      const dist = Math.abs(sec.offsetTop - scrollY);
      if (dist < minDist) {
        minDist = dist;
        closest = i;
      }
    });

    this.target = { ...this.positions[closest] };
  }

  resize() {
    const container = document.getElementById("container3D");
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.camera.aspect = container.clientWidth / container.clientHeight;
    this.camera.updateProjectionMatrix();
  }

  animate() {
    requestAnimationFrame(() => this.animate());

    if (this.phone) {
      const ease = 0.06;
      const floatPos = Math.sin(Date.now() * 0.0012) * 0.06;

      this.current.x += (this.target.x - this.current.x) * ease;
      this.current.y += ((this.target.y + floatPos) - this.current.y) * ease;

      this.phone.position.set(this.current.x, this.current.y, 0);

      const scroller = document.querySelector(".scroll-container");
      const maxScroll = scroller.scrollHeight - innerHeight;
      const progress = scroller.scrollTop / maxScroll;

      this.camera.position.z +=
        ((4.6 + progress * 1.0) - this.camera.position.z) * 0.04;
    }

    this.renderer.render(this.scene, this.camera);
  }
}

document.addEventListener("DOMContentLoaded", () => new PhoneShowcase());
